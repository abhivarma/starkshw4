import {NgModule} from '@angular/core';
import {TicketListComponent} from '../../components/ticket-list/ticket-list.component';

@NgModule({
  imports: [
  ],
  declarations: [
    TicketListComponent]
})

export class TicketModule { }
